<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

echo "<div class=\"page\">\r\n  <table class=\"table tb-type2\">\r\n    <thead>\r\n      <tr class=\"space\">\r\n        <th colspan=\"10\" class=\"nobg big\">";
echo $lang['dashboard_aboutus_idea'];
echo "</th>\r\n      </tr>\r\n    </thead>\r\n    <tbody>\r\n      <tr>\r\n        <td class=\"w12\"></td>\r\n        <td>";
echo $lang['dashboard_aboutus_idea_content'];
echo "</td>\r\n      </tr>\r\n    </tbody><tfoot>\r\n      <tr class=\"tfoot\">\r\n        <td colspan=\"10\"></td>\r\n      </tr>\r\n    </tfoot>\r\n  </table>\r\n  <table class=\"table tb-type2\">\r\n    <thead>\r\n      <tr class=\"space\">\r\n        <th colspan=\"10\" class=\"nobg big\">";
echo $lang['dashboard_aboutus_team'];
echo "</th>\r\n      </tr>\r\n    </thead>\r\n    <tbody>\r\n      <tr>\r\n        <td class=\"w12\"></td>\r\n        <td class=\"w96\">";
echo $lang['dashboard_aboutus_manager'];
echo "&nbsp;:&nbsp;</td>\r\n        <td class=\"team\">";
echo $lang['dashboard_aboutus_manager_name'];
echo "</td>\r\n      </tr>\r\n      <tr class=\"noborder\">\r\n        <td></td>\r\n        <td>";
echo $lang['dashboard_aboutus_developer'];
echo "&nbsp;:&nbsp;</td>\r\n        <td class=\"team\">";
echo $lang['dashboard_aboutus_developer_name'];
echo "</td>\r\n      </tr>\r\n      <tr class=\"noborder\">\r\n        <td></td>\r\n        <td>";
echo $lang['dashboard_aboutus_designer'];
echo "&nbsp;:&nbsp;</td>\r\n        <td class=\"team\">";
echo $lang['dashboard_aboutus_designer_name'];
echo "</td>\r\n      </tr>\r\n    </tbody>\r\n    <tfoot>\r\n      <tr class=\"tfoot\">\r\n        <td colspan=\"10\"></td>\r\n      </tr>\r\n    </tfoot>\r\n  </table>\r\n  <table class=\"table tb-type2\">\r\n    <thead>\r\n      <tr class=\"space\">\r\n        <th colspan=\"10\" class=\"nobg big\">";
echo $lang['dashboard_aboutus_near_us'];
echo "</th>\r\n      </tr>\r\n    </thead>\r\n    <tbody>\r\n      <tr>\r\n        <td class=\"w12\"></td>\r\n        <td><strong>";
echo $lang['dashboard_aboutus_bbs'];
echo "</strong>&nbsp;&nbsp;&nbsp;(&nbsp;<span>";
echo $lang['dashboard_aboutus_bbs_tip'];
echo "</span>&nbsp;)&nbsp;</td>\r\n      </tr>\r\n      <tr class=\"noborder\">\r\n        <td></td>\r\n        <td><a href=\"http://bbs.shopnc.net\" target=\"_blank\">http://bbs.shopnc.net</a></td>\r\n      </tr>\r\n      <tr class=\"noborder\">\r\n        <td></td>\r\n        <td><strong>";
echo $lang['dashboard_aboutus_website'];
echo "</strong>&nbsp;&nbsp;&nbsp;(&nbsp;<span>";
echo $lang['dashboard_aboutus_website_tip'];
echo "</span>&nbsp;)&nbsp;</td>\r\n      </tr>\r\n      <tr class=\"noborder\">\r\n        <td></td>\r\n        <td><a href=\"http://www.shopnc.net\" target=\"_blank\">http://www.shopnc.net</a></td>\r\n      </tr>\r\n    </tbody>\r\n    <tfoot>\r\n      <tr class=\"tfoot\">\r\n        <td colspan=\"10\"></td>\r\n      </tr>\r\n    </tfoot>\r\n  </table>\r\n  <table class=\"table tb-type2\">\r\n    <thead>\r\n      <tr class=\"space\">\r\n        <th colspan=\"10\" class=\"nobg big\">";
echo $lang['dashboard_aboutus_thanks'];
echo "</th>\r\n      </tr>\r\n    </thead>\r\n    <tbody>\r\n      <tr>\r\n        <td class=\"w12\"></td>\r\n        <td><strong>";
echo $lang['dashboard_aboutus_thanks_content'];
echo "</strong></td>\r\n      </tr>\r\n      <tr class=\"noborder\">\r\n        <td></td>\r\n        <td><a href=\"http://www.shopnc.net\" target=\"_blank\">";
echo $lang['dashboard_aboutus_thanks_developer_name'];
echo "</a></td>\r\n      </tr>\r\n    </tbody>\r\n    <tfoot>\r\n      <tr class=\"tfoot\">\r\n        <td colspan=\"10\"></td>\r\n      </tr>\r\n    </tfoot>\r\n  </table>\r\n  <table class=\"table tb-type2\">\r\n    <thead>\r\n      <tr class=\"space\">\r\n        <th colspan=\"10\" class=\"nobg big\">";
echo $lang['dashboard_aboutus_notice'];
echo "</th>\r\n      </tr>\r\n    </thead>\r\n    <tbody>\r\n      <tr>\r\n        <td class=\"w12\"></td>\r\n        <td><a href=\"http://www.shopnc.net\" target=\"_blank\">";
echo $lang['dashboard_aboutus_notice1'];
echo "</a>&nbsp;";
echo $lang['dashboard_aboutus_notice2'];
echo "&nbsp;<a href=\"http://www.shopnc.net\" target=\"_blank\">ShopNC</a>&nbsp;";
echo $lang['dashboard_aboutus_notice3'];
echo "</td>\r\n      </tr>\r\n      <tr class=\"noborder\">\r\n        <td></td>\r\n        <td>";
echo $lang['dashboard_aboutus_notice4'];
echo "&nbsp;:&nbsp;&nbsp;jQuery,Swfupload,kindeditor";
echo $lang['dashboard_aboutus_notice5'];
echo ".&nbsp;";
echo $lang['dashboard_aboutus_notice6'];
echo "</td>\r\n      </tr>\r\n    </tbody>\r\n    <tfoot>\r\n      <tr class=\"tfoot\">\r\n        <td colspan=\"10\"></td>\r\n      </tr>\r\n    </tfoot>\r\n  </table>\r\n</div>\r\n";
?>
