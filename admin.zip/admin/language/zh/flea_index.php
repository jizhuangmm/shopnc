<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

if ( !defined( "InShopNC" ) )
{
		exit( "Access Invalid!" );
}
$lang['flea_index_unable'] = "系統未開啟閒置市場功能";
$lang['flea_ldle'] = "閒置物品";
$lang['flea_all_ldle'] = "所有閒置物品";
$lang['flea_ldle_name'] = "閒置物品名";
$lang['flea_release_member'] = "發佈會員名";
?>
