<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

if ( !defined( "InShopNC" ) )
{
		exit( "Access Invalid!" );
}
$lang['admin_updatestat'] = "更新統計";
$lang['admin_fornum'] = "每個循環更新數量";
$lang['admin_buyerevalstat'] = "買家信用";
$lang['admin_update'] = "更新";
$lang['admin_sellerevalstat'] = "賣家信用";
$lang['admin_storeevalstat'] = "店舖動態評分";
$lang['admin_goodsevalcount'] = "商品評價數統計";
$lang['admin_updatesuccess'] = "更新完成";
$lang['admin_updatedoing'] = "正在更新中......";
$lang['admin_nextstep'] = "下一步";
$lang['admin_cancelupdate'] = "取消更新";
?>
