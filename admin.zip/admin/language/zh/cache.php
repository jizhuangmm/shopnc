<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

if ( !defined( "InShopNC" ) )
{
		exit( "Access Invalid!" );
}
$lang['cache_cls_operate'] = "清理緩存";
$lang['cache_cls_all'] = "全部";
$lang['cache_cls_seting'] = "商城配置";
$lang['cache_cls_category'] = "商品分類";
$lang['cache_cls_adv'] = "廣告緩存";
$lang['cache_cls_group'] = "團購緩存（地區|分類|價格區間）";
$lang['cache_cls_link'] = "友情連結";
$lang['cache_cls_nav'] = "底部導航";
$lang['cache_cls_index'] = "首頁";
$lang['cache_cls_table'] = "表結構";
$lang['cache_cls_express'] = "快遞公司";
$lang['cache_cls_store_class'] = "店舖分類";
$lang['cache_cls_store_grade'] = "店舖等級";
$lang['cache_cls_ok'] = "更新成功";
?>
