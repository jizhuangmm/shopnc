<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

if ( !defined( "InShopNC" ) )
{
		exit( "Access Invalid!" );
}
$lang['login_index_username_null'] = "用户名不能为空";
$lang['login_index_password_null'] = "密码不能为空";
$lang['login_index_checkcode_null'] = "验证码不能为空";
$lang['login_index_checkcode_wrong'] = "验证码输入错误，请重新输入";
$lang['login_index_not_admin'] = "您不是管理员，不能进入后台";
$lang['login_index_username_password_wrong'] = "帐号密码错误";
$lang['login_index_need_login'] = "您需要登录后才可以使用本功能";
$lang['login_index_username'] = "用户名";
$lang['login_index_password'] = "密　码";
$lang['login_index_checkcode'] = "验证码";
$lang['login_index_change_checkcode'] = "看不清,点击更换验证码";
$lang['login_index_back_to_homepage'] = "返回商城首页";
$lang['login_index_forget_password'] = "忘记了密码";
$lang['login_index_shopnc'] = "天津市网城创想科技有限责任公司";
?>
