<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

if ( !defined( "InShopNC" ) )
{
		exit( "Access Invalid!" );
}
$lang['feedback_mange_title'] = "意见反馈";
$lang['feedback_del_succ'] = "删除成功";
$lang['feedback_del_fiald'] = "删除失败";
$lang['feedback_index_content'] = "反馈内容";
$lang['feedback_index_time'] = "时间";
$lang['feedback_index_from'] = "来自";
?>
