<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

if ( !defined( "InShopNC" ) )
{
		exit( "Access Invalid!" );
}
$lang['flea_index_setting'] = "闲置页面设置";
$lang['flea_index_seo_setting'] = "SEO设置";
$lang['flea_site_name'] = "闲置首页名称";
$lang['flea_site_title'] = "闲置首页标题";
$lang['flea_site_description'] = "闲置首页描述";
$lang['flea_site_keywords'] = "闲置首页关键字";
$lang['flea_hot_search'] = "闲置首页热门搜索";
$lang['flea_isuse_off_tips'] = "闲置市场功能未开启";
?>
