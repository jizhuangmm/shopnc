<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

if ( !defined( "InShopNC" ) )
{
		exit( "Access Invalid!" );
}
$lang['admin_updatestat'] = "更新统计";
$lang['admin_fornum'] = "每个循环更新数量";
$lang['admin_buyerevalstat'] = "买家信用";
$lang['admin_update'] = "更新";
$lang['admin_sellerevalstat'] = "卖家信用";
$lang['admin_storeevalstat'] = "店铺动态评分";
$lang['admin_goodsevalcount'] = "商品评价数统计";
$lang['admin_updatesuccess'] = "更新完成";
$lang['admin_updatedoing'] = "正在更新中......";
$lang['admin_nextstep'] = "下一步";
$lang['admin_cancelupdate'] = "取消更新";
?>
