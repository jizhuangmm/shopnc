<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

if ( !defined( "InShopNC" ) )
{
		exit( "Access Invalid!" );
}
$lang['cache_cls_operate'] = "清理缓存";
$lang['cache_cls_all'] = "全部";
$lang['cache_cls_seting'] = "商城配置";
$lang['cache_cls_category'] = "商品分类";
$lang['cache_cls_adv'] = "广告缓存";
$lang['cache_cls_group'] = "团购缓存（地区|分类|价格区间）";
$lang['cache_cls_link'] = "友情链接";
$lang['cache_cls_nav'] = "底部导航";
$lang['cache_cls_index'] = "首页";
$lang['cache_cls_table'] = "表结构";
$lang['cache_cls_express'] = "快递公司";
$lang['cache_cls_store_class'] = "店铺分类";
$lang['cache_cls_store_grade'] = "店铺等级";
$lang['cache_cls_ok'] = "更新成功";
?>
